// src/router/index.js
const Router = {
  init(mainElement, routesConfig) {
    this.mainElement = mainElement;
    this.routes = routesConfig;
    this.currentView = null;

    // Dengarkan perubahan hash
    window.addEventListener('hashchange', () => this.handleRouteChange());
    // Tangani rute awal saat halaman dimuat
    this.handleRouteChange();
  },

  async handleRouteChange() {
    const hash = window.location.hash || '#'; // Ambil hash saat ini, default ke '#'
    const path = hash === '#' ? '' : hash;    // Normalisasi path untuk pencarian rute

    const ViewClass = this.routes[path] || this.routes['']; // Fallback ke rute default jika tidak ditemukan

    if (ViewClass) {
      // Jika view saat ini memiliki metode unmount/cleanup, panggil sebelum mengganti
      if (this.currentView && typeof this.currentView.unmount === 'function') {
        this.currentView.unmount();
      }

      const viewInstance = new ViewClass(this.mainElement);
      this.currentView = viewInstance;

      const renderView = async () => {
        this.mainElement.innerHTML = ''; // Bersihkan konten lama
        await viewInstance.render();      // Panggil metode render dari instance view
        // Panggil afterRender jika ada, untuk logika setelah DOM dirender (misal: event listener, inisialisasi peta)
        if (typeof viewInstance.afterRender === 'function') {
          await viewInstance.afterRender();
        }
      };

      // Implementasi View Transition API (Kriteria Wajib 6)
      if (document.startViewTransition) {
        document.startViewTransition(renderView);
      } else {
        await renderView(); // Fallback jika View Transition API tidak didukung
      }
    } else {
      this.mainElement.innerHTML = '<p>404 - Halaman tidak ditemukan.</p>';
      if (this.currentView && typeof this.currentView.unmount === 'function') {
        this.currentView.unmount();
        this.currentView = null;
      }
    }
  },
};

export default Router;
