// src/app.js
import Router from './router/index.js';
import StoryListView from './views/story-list-view.js';
import AddStoryView from './views/add-story-view.js';
import LoginView from './views/login-view.js'; // Tambahkan ini
import RegisterView from './views/register-view.js'; // Tambahkan ini
import { getAuthToken, getAuthUserName, removeAuthToken } from './api/story-api-config.js';
import './styles/main.css'; // Atau lokasi file CSS Anda
import L from 'leaflet';
import 'leaflet/dist/leaflet.css'; // Impor CSS Leaflet
import iconRetinaUrl from 'leaflet/dist/images/marker-icon-2x.png';
import iconUrl from 'leaflet/dist/images/marker-icon.png';
import shadowUrl from 'leaflet/dist/images/marker-shadow.png';

delete L.Icon.Default.prototype._getIconUrl; // Hapus getter lama jika ada

L.Icon.Default.mergeOptions({
  iconRetinaUrl: iconRetinaUrl,
  iconUrl: iconUrl,
  shadowUrl: shadowUrl,
});

const mainContentElement = document.getElementById('main-content');
const navAuthContainer = document.getElementById('navAuthContainer'); // Kita butuh elemen ini di HTML

const routes = {
  '': StoryListView,
  '#stories': StoryListView,
  '#add-story': AddStoryView,
  '#login': LoginView,       // Rute untuk login
  '#register': RegisterView, // Rute untuk register
  // '#story/:id': StoryDetailView, // Anda perlu membuat View dan Presenter untuk ini
};

function updateNavAuth() {
  const token = getAuthToken();
  const userName = getAuthUserName();

  if (token && navAuthContainer) {
    navAuthContainer.innerHTML = `
      <li class="nav-greeting">Halo, ${userName || 'Pengguna'}!</li>
      <li><a href="#" id="logoutButton">Logout</a></li>
    `;
    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
      logoutButton.addEventListener('click', (event) => {
        event.preventDefault();
        removeAuthToken();
        updateNavAuth(); // Update tampilan nav
        window.location.hash = '#login'; // Arahkan ke login setelah logout
        window.location.reload(); // Atau reload agar semua state bersih
      });
    }
  } else if (navAuthContainer) {
    navAuthContainer.innerHTML = `
      <li><a href="#login">Login</a></li>
      <li><a href="#register">Register</a></li>
    `;
  }
}

function initializeApp() {
  if (!mainContentElement) {
    console.error('Elemen konten utama (#main-content) tidak ditemukan!');
    return;
  }
  Router.init(mainContentElement, routes);
  updateNavAuth(); // Panggil untuk set tampilan nav awal
}

window.addEventListener('DOMContentLoaded', initializeApp);
// Panggil updateNavAuth setiap kali hash berubah juga, atau setelah login sukses
window.addEventListener('hashchange', () => {
  // Jika perlu, update UI tertentu berdasarkan hash, tapi navAuth lebih ke status login
  // Jika login view memodifikasi token, kita perlu cara untuk memicu updateNavAuth
});

// Event listener kustom untuk memicu update UI setelah login/logout
// LoginView bisa dispatch event ini setelah login sukses.
window.addEventListener('authChanged', () => {
  updateNavAuth();
});
