// webpack.config.js
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin'); // Untuk menyalin aset

module.exports = (env, argv) => {
  const isProduction = argv.mode === 'production';

  return {
    mode: isProduction ? 'production' : 'development',
    entry: {
      app: './src/app.js', // Titik masuk utama aplikasi Anda
    },
    output: {
      filename: isProduction ? '[name].[contenthash].bundle.js' : '[name].bundle.js', // Gunakan contenthash untuk cache busting di produksi
      path: path.resolve(__dirname, 'dist'),
      clean: true, // Membersihkan folder /dist sebelum setiap build (Webpack 5+)
      publicPath: '/', // Path publik untuk aset
    },
    devtool: isProduction ? 'source-map' : 'eval-source-map', // Source map untuk debugging
    devServer: {
      static: {
        directory: path.resolve(__dirname, 'dist'), // Folder yang akan di-serve
      },
      compress: true, // Aktifkan kompresi gzip
      port: 8080, // Port development server
      open: true, // Buka browser secara otomatis
      hot: true, // Aktifkan Hot Module Replacement (HMR)
      historyApiFallback: true, // Penting untuk SPA agar routing sisi klien berfungsi dengan benar saat refresh
    },
    module: {
      rules: [
        {
          test: /\.js$/, // Untuk semua file .js
          exclude: /node_modules/, // Kecualikan folder node_modules
          use: {
            loader: 'babel-loader', // Gunakan Babel untuk transpiling
            options: {
              presets: ['@babel/preset-env'], // Preset standar Babel
            },
          },
        },
        {
          test: /\.css$/, // Untuk semua file .css
          use: [
            'style-loader', // 3. Menyuntikkan style ke dalam DOM
            'css-loader',   // 2. Menerjemahkan @import dan url() seperti import/require()
          ],
        },
        {
          test: /\.(png|svg|jpg|jpeg|gif)$/i, // Untuk file gambar
          type: 'asset/resource', // Webpack 5 asset modules
          generator: {
            filename: 'assets/images/[hash][ext][query]',
          },
        },
        {
          test: /\.(woff|woff2|eot|ttf|otf)$/i, // Untuk file font
          type: 'asset/resource',
          generator: {
            filename: 'assets/fonts/[hash][ext][query]',
          },
        },
      ],
    },
    plugins: [
      new HtmlWebpackPlugin({
        template: './src/index.html', // Path ke file template HTML Anda
        filename: 'index.html',       // Nama file HTML output di folder /dist
        inject: 'body',               // Suntikkan skrip di akhir body
        favicon: './src/assets/favicon.ico', // Opsional: jika Anda punya favicon
      }),
      new CopyWebpackPlugin({ // Opsional: jika Anda punya aset lain yang perlu disalin
        patterns: [
          {
            from: path.resolve(__dirname, 'src/assets/images'), // Salin dari src/assets/images
            to: path.resolve(__dirname, 'dist/assets/images'),   // Ke dist/assets/images
            noErrorOnMissing: true, // Tidak error jika folder sumber tidak ada
          },
          // Tambahkan pola lain jika perlu, misalnya untuk file manifest.json
          // {
          //   from: path.resolve(__dirname, 'src/manifest.json'),
          //   to: path.resolve(__dirname, 'dist/manifest.json'),
          //   noErrorOnMissing: true,
          // },
        ],
      }),
    ],
    optimization: { // Optimasi untuk mode produksi
      splitChunks: {
        chunks: 'all', // Memisahkan vendor code dari application code
      },
      runtimeChunk: 'single', // Membuat runtime chunk terpisah
    },
    performance: {
      hints: isProduction ? 'warning' : false, // Memberi warning jika bundle terlalu besar di produksi
    },
  };
};
