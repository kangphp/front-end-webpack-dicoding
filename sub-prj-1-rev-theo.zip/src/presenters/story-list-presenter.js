// src/presenters/story-list-presenter.js
export class StoryListPresenter {
  constructor(model, view) {
    this.model = model;
    this.view = view;
  }

  async loadStories() {
    try {
      this.view.showLoading();
      const stories = await this.model.getAllStories(); // Ambil dari model
      this.view.renderStories(stories); // Kirim ke view untuk ditampilkan
    } catch (error) {
      console.error('Error loading stories:', error);
      this.view.renderErrorMessage(error.message || 'Terjadi kesalahan saat memuat cerita.');
    } finally {
      this.view.hideLoading();
    }
  }
}
